package farmacia_san_antonio;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import conexión.ConexionBD;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.awt.Image;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author frix4
 */
public class Venta extends javax.swing.JFrame {

    private static Venta instancia;
    private DefaultTableModel modeloTabla;
    private List<Ticket> historicoVentas = new ArrayList<>();
    private ImageIcon imagen;
    private Icon icono;

    ConexionBD con = new ConexionBD();
    Connection cn = con.getConexion();

    public Venta() {
        initComponents();
        this.setLocationRelativeTo(this);
        iniciarRelojEnTiempoReal();
        configurarModeloTabla();
        this.pintarimagen(this.logo1, "C:\\Users\\frix4\\Documentos\\NetBeansProjects\\Farmacia_san_antonio\\src\\imagenes\\logo.jpg");
        this.pintarimagen(this.busqueda, "C:\\Users\\frix4\\Documentos\\NetBeansProjects\\Farmacia_san_antonio\\src\\imagenes\\lupa.png");
    }

    private void iniciarRelojEnTiempoReal() {
        // Formateador de fecha/hora
        DateTimeFormatter formateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // Timer que se ejecuta cada 1000 ms (1 segundo)
        Timer timer = new Timer(1000, e -> {
            LocalDateTime ahora = LocalDateTime.now();
            txtfecha.setText(ahora.format(formateador));
        });

        timer.start(); // Iniciar el timer

        // Actualización inicial (para que no tarde 1 segundo en aparecer)
        txtfecha.setText(LocalDateTime.now().format(formateador));
    }

    private List<Ticket> ventasRealizadas = new ArrayList<>();

    private void configurarModeloTabla() {
        modeloTabla = new DefaultTableModel(
                new Object[]{"CODIGO DE BARRAS", "NOMBRE DE PRODUCTO", "CANTIDAD", "PRECIO", "TOTAL"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2; // Solo editable la columna CANTIDAD
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 4 ? Double.class : Object.class;
            }
        };

        contenido.setModel(modeloTabla);

        modeloTabla.addTableModelListener(e -> {
            if (e.getColumn() == 2) {
                actualizarFila(e.getFirstRow());
                actualizarTotal();
            }
        });
    }

    private void actualizarFila(int fila) {
        try {
            int cantidad = Integer.parseInt(modeloTabla.getValueAt(fila, 2).toString());
            double precio = Double.parseDouble(modeloTabla.getValueAt(fila, 3).toString());
            double total = cantidad * precio;
            modeloTabla.setValueAt(total, fila, 4);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Cantidad inválida");
            modeloTabla.setValueAt(1, fila, 2); // Resetear a cantidad 1
        }
    }

    public void limpiarVentaActual() {
        modeloTabla.setRowCount(0);
        actualizarTotal();
        // Limpiar otros campos si existen
        // txtCliente.setText("");
        // txtVendedor.setText("");
    }

    public void guardarVentaEnHistorial() {
        List<ProductoVendido> productos = new ArrayList<>();

        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            productos.add(new ProductoVendido(
                    modeloTabla.getValueAt(i, 0).toString(), // Código
                    modeloTabla.getValueAt(i, 1).toString(), // Nombre
                    Integer.parseInt(modeloTabla.getValueAt(i, 2).toString()), // Cantidad
                    Double.parseDouble(modeloTabla.getValueAt(i, 3).toString()) // Precio
            ));
        }
    }

    private void guardarTicketEnArchivo(Ticket ticket) {
        // Implementación para guardar en base de datos o archivo
    }

    private void generarPDFTicket(Ticket ticket) {
        // Implementación para generar PDF
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btncobro = new javax.swing.JButton();
        buscar = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        logo1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        contenido = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        busqueda = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        sumatotal = new javax.swing.JLabel();
        txtfecha = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setPreferredSize(new java.awt.Dimension(1500, 750));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btncobro.setBackground(new java.awt.Color(9, 118, 68));
        btncobro.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btncobro.setForeground(new java.awt.Color(0, 0, 0));
        btncobro.setText("Cobrar");
        btncobro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btncobroMouseClicked(evt);
            }
        });
        btncobro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncobroActionPerformed(evt);
            }
        });
        jPanel1.add(btncobro, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 600, 110, 40));

        buscar.setBackground(new java.awt.Color(255, 255, 255));
        buscar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        buscar.setForeground(new java.awt.Color(0, 0, 0));
        buscar.setText("Ingrese folio o nombre del producto");
        buscar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        buscar.setCaretColor(new java.awt.Color(255, 255, 255));
        buscar.setOpaque(false);
        buscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buscarMouseClicked(evt);
            }
        });
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });
        jPanel1.add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 80, 320, 30));
        buscar.getAccessibleContext().setAccessibleName("buscar producto");

        jButton1.setBackground(new java.awt.Color(9, 118, 68));
        jButton1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton1.setText("Buscar");
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 80, 110, 30));

        logo1.setToolTipText("");
        logo1.setAutoscrolls(true);
        logo1.setBorder(new javax.swing.border.MatteBorder(null));
        logo1.setMaximumSize(new java.awt.Dimension(90, 26));
        logo1.setMinimumSize(new java.awt.Dimension(90, 26));
        logo1.setName(""); // NOI18N
        jPanel1.add(logo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 100));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(9, 118, 68));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("FARMACIA SAN ANTONIO");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, 460, 40));

        contenido.setBackground(new java.awt.Color(204, 204, 204));
        contenido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "CODIGO DE BARRA", "NOMBRE DE PRODUCTO", "CANTIDAD", "PRECIO", "TOTAL"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        contenido.setShowHorizontalLines(false);
        jScrollPane2.setViewportView(contenido);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 1000, 450));

        jButton3.setBackground(new java.awt.Color(153, 255, 255));
        jButton3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton3.setText("Ventas del dia");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 430, 110, 30));

        busqueda.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(busqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 80, 30, 30));

        jButton4.setBackground(new java.awt.Color(204, 0, 0));
        jButton4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 0, 0));
        jButton4.setText("Eliminar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 160, 110, 30));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Total:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 600, 80, 40));

        sumatotal.setBackground(new java.awt.Color(204, 204, 204));
        sumatotal.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        sumatotal.setForeground(new java.awt.Color(0, 0, 0));
        sumatotal.setText("$ 00.00");
        sumatotal.setOpaque(true);
        jPanel1.add(sumatotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 600, 110, 40));

        txtfecha.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jPanel1.add(txtfecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 650, 260, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1422, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        String criterio = buscar.getText().trim();

        // Validar criterio de búsqueda
        if (criterio.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Ingrese un nombre o código de barras",
                    "Búsqueda vacía",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "SELECT codigo_barras, nombre, stock, precio "
                + "FROM productos "
                + "WHERE (nombre LIKE ? OR codigo_barras = ?) "
                + "AND stock > 0";

        DefaultTableModel model = (DefaultTableModel) contenido.getModel();
        Set<String> productosEnTabla = new HashSet<>();

        // Pre-cargar códigos de barras existentes en la tabla
        for (int i = 0; i < model.getRowCount(); i++) {
            productosEnTabla.add(model.getValueAt(i, 0).toString());
        }

        try ( PreparedStatement pstmt = cn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + criterio + "%");
            pstmt.setString(2, criterio);

            ResultSet rs = pstmt.executeQuery();
            boolean resultadosEncontrados = false;

            while (rs.next()) {
                String codigoBarras = rs.getString("codigo_barras");
                String nombre = rs.getString("nombre");
                int stock = rs.getInt("stock");
                double precio = rs.getDouble("precio");
                resultadosEncontrados = true;

                // Validar stock antes de agregar
                if (stock <= 0) {
                    JOptionPane.showMessageDialog(this,
                            "Producto '" + nombre + "' sin stock disponible",
                            "Stock agotado",
                            JOptionPane.WARNING_MESSAGE);
                    continue;
                }

                // Verificar existencia usando el Set
                if (productosEnTabla.contains(codigoBarras)) {
                    for (int i = 0; i < model.getRowCount(); i++) {
                        if (model.getValueAt(i, 0).equals(codigoBarras)) {
                            int cantidadActual = (int) model.getValueAt(i, 2);
                            if (cantidadActual + 1 > stock) {
                                JOptionPane.showMessageDialog(this,
                                        "No hay suficiente stock para '" + nombre + "'",
                                        "Error de stock",
                                        JOptionPane.ERROR_MESSAGE);
                                break;
                            }
                            model.setValueAt(cantidadActual + 1, i, 2);
                            model.setValueAt((cantidadActual + 1) * precio, i, 4);
                            break;
                        }
                    }
                } else {
                    model.addRow(new Object[]{
                        codigoBarras,
                        nombre,
                        1, // Cantidad inicial
                        precio,
                        precio // Total inicial
                    });
                    productosEnTabla.add(codigoBarras);
                }
            }

            if (!resultadosEncontrados) {
                JOptionPane.showMessageDialog(this,
                        "No se encontraro el producto",
                        "Sin resultados",
                        JOptionPane.INFORMATION_MESSAGE);
            }

            actualizarTotal();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error al buscar productos. Intente nuevamente.",
                    "Error de base de datos",
                    JOptionPane.ERROR_MESSAGE);
            //Logger.getLogger(Venta.class.getName()).log(Level.SEVERE, "Error SQL", e);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error inesperado: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
        buscar.setText(" ");
    }//GEN-LAST:event_buscarActionPerformed

    private void buscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buscarMouseClicked
        buscar.setText(" ");
    }//GEN-LAST:event_buscarMouseClicked
    double getTotalVenta() {
        double total = 0.0;
        for (int i = 0; i < contenido.getRowCount(); i++) {
            total += (double) contenido.getValueAt(i, 4); // Columna 4: Total
        }
        return total;
    }

    public static Venta getInstancia() {
        if (instancia == null) {
            instancia = new Venta();
        }
        return instancia;
    }

    // 4. Anular dispose() para reiniciar Singleton al cerrar
    @Override
    public void dispose() {
        instancia = null;
        super.dispose();
    }

    private void btncobroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncobroMouseClicked
        if (modeloTabla.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Agrega productos primero");
            return;
        }

        double totalVenta = calcularTotal();

        // 1. Crear ventana de cobro con referencia a esta instancia de Venta
        Cobro cobro = new Cobro(this, totalVenta);

        // 2. Ocultar ventana actual de venta
        this.setVisible(false);

        // 3. Mostrar ventana de cobro
        cobro.setVisible(true);
    }//GEN-LAST:event_btncobroMouseClicked
    public void guardarTicket() {
        StringBuilder contenido = new StringBuilder();

        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            String producto = modeloTabla.getValueAt(i, 1).toString();
            String cantidad = modeloTabla.getValueAt(i, 2).toString();
            String precio = modeloTabla.getValueAt(i, 3).toString();
            String total = modeloTabla.getValueAt(i, 4).toString();

            contenido.append(producto)
                    .append(",")
                    .append(cantidad)
                    .append(",")
                    .append(precio)
                    .append(",")
                    .append(total)
                    .append("\n");
        }

        generarPDF(contenido.toString());
    }

    public void limpiarVenta() {
        modeloTabla.setRowCount(0);
        actualizarTotal(); // Resetear total a 0
        // Limpiar otros campos si existen
        // txtCliente.setText("");
        // txtVendedor.setText("");
    }

    private void guardarEnArchivo(String contenido) {
        try ( FileWriter writer = new FileWriter("ventas.txt", true)) {
            writer.write(contenido + "\n\n");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void generarPDF(String contenido) {
        // 1. Configuración inicial con constantes
        final String DIRECTORIO_BASE = "tickets/"; // Ruta relativa
        final String RUTA_LOGO = "src/imagenes/logo.jpg"; // Ruta relativa al proyecto

        Document document = null;
        try {
            // 2. Configurar formato de fecha
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
            String nombreArchivo = "ticket_" + sdf.format(new Date()) + ".pdf";

            // 3. Crear directorio si no existe
            File carpeta = new File(DIRECTORIO_BASE);
            if (!carpeta.exists() && !carpeta.mkdirs()) {
                throw new IOException("No se pudo crear el directorio: " + carpeta.getAbsolutePath());
            }

            // 4. Configurar documento PDF
            document = new Document(PageSize.A4, 20, 20, 40, 40);
            PdfWriter.getInstance(document, new FileOutputStream(DIRECTORIO_BASE + nombreArchivo));
            document.open();

            // 5. Agregar logo
            /*Image logo = Image.getInstance(RUTA_LOGO);
        logo.scaleAbsolute(80, 80);
        logo.setAlignment(Image.ALIGN_CENTER);
        document.add(logo);*/
            // 6. Encabezado
            Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
            Paragraph titulo = new Paragraph("Farmacia San Antonio\n\n", fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);

            Date fechaActual = new Date();
            SimpleDateFormat fecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String fechaFormateada = fecha.format(fechaActual);
            document.add(titulo);
            document.add(new Paragraph("RFC: EIRFQJUR8485711 "));
            document.add(new Paragraph(" "));
            document.add(new Paragraph("Fecha: " + fechaFormateada));
            document.add(new Paragraph(" "));

            // 7. Crear tabla con datos reales
            PdfPTable tabla = crearTablaProductos(contenido); // Método separado
            document.add(tabla);

            // 8. Total y mensaje final
            Paragraph total = new Paragraph(
                    "\nTotal: $" + String.format("%.2f", calcularTotal()),
                    new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)
            );
            total.setAlignment(Element.ALIGN_RIGHT);
            total.setSpacingBefore(10f);
            document.add(total);

// Configurar mensaje final
            Paragraph gracias = new Paragraph(
                    "\nGracias por su compra!",
                    new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC)
            );
            gracias.setAlignment(Element.ALIGN_RIGHT);
            gracias.setSpacingAfter(15f);
            document.add(gracias);

            // 9. Notificación de éxito
            JOptionPane.showMessageDialog(this,
                    "Ticket generado en: " + carpeta.getAbsolutePath(),
                    "Compra Exitosa",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException | DocumentException e) {
            manejarErrorPDF(e); // Método separado para manejo de errores
        } finally {
            if (document != null) {
                document.close();
            }
        }
    }

// Método auxiliar para crear la tabla
    private PdfPTable crearTablaProductos(String contenido) throws BadElementException, DocumentException {
        PdfPTable tabla = new PdfPTable(4); // 4 columnas
        tabla.setWidthPercentage(100);
        tabla.setWidths(new float[]{3, 1, 2, 2}); // Anchos relativos

        // Encabezados
        String[] headers = {"Producto", "Cantidad", "Precio Unitario", "Total"};
        for (String header : headers) {
            PdfPCell celda = new PdfPCell(new Phrase(header));
            celda.setBackgroundColor(new BaseColor(200, 200, 200));
            celda.setHorizontalAlignment(Element.ALIGN_CENTER);
            tabla.addCell(celda);
        }

        // Datos
        String[] filas = contenido.split("\n");
        for (String fila : filas) {
            String[] datos = fila.split(",");
            if (datos.length == 4) {
                // Producto
                PdfPCell celdaProducto = new PdfPCell(new Phrase(datos[0].trim()));
                celdaProducto.setHorizontalAlignment(Element.ALIGN_LEFT);

                // Cantidad
                PdfPCell celdaCantidad = new PdfPCell(new Phrase(datos[1].trim()));
                celdaCantidad.setHorizontalAlignment(Element.ALIGN_CENTER);

                // Precio
                PdfPCell celdaPrecio = new PdfPCell(new Phrase("$" + datos[2].trim()));
                celdaPrecio.setHorizontalAlignment(Element.ALIGN_RIGHT);

                // Total
                PdfPCell celdaTotal = new PdfPCell(new Phrase("$" + datos[3].trim()));
                celdaTotal.setHorizontalAlignment(Element.ALIGN_RIGHT);

                tabla.addCell(celdaProducto);
                tabla.addCell(celdaCantidad);
                tabla.addCell(celdaPrecio);
                tabla.addCell(celdaTotal);
            }
        }
        return tabla;
    }

// Método para manejo de errores
    private void manejarErrorPDF(Exception e) {
        String mensaje = "Error al generar PDF: \n" + e.getMessage();
        if (e instanceof IOException) {
            mensaje += "\nVerifique permisos de escritura";
        }
        JOptionPane.showMessageDialog(this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        eliminarFilasSeleccionadas();
    }//GEN-LAST:event_jButton4ActionPerformed
    public void guardarVenta() {
        // Obtener datos de la tabla
        List<Object[]> datosVenta = new ArrayList<>();
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            Object[] fila = {
                modeloTabla.getValueAt(i, 0), // ID
                modeloTabla.getValueAt(i, 1), // Nombre
                modeloTabla.getValueAt(i, 2), // Precio
                modeloTabla.getValueAt(i, 3) // Cantidad
            };
            datosVenta.add(fila);
        }

        // Crear ticket
        Ticket ticket = new Ticket(
                txtfecha.getText(),
                datosVenta,
                Double.parseDouble(sumatotal.getText().replace("$", "").trim())
        );

        // Guardar en histórico
        historicoVentas.add(ticket);

        // Guardar en archivo
        guardarEnArchivo(ticket);
    }

    private void guardarEnArchivo(Ticket ticket) {
        try ( FileWriter writer = new FileWriter("ventas.csv", true)) {
            writer.write(ticket.toCSV() + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar venta: " + e.getMessage());
        }
    }
    private void btncobroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncobroActionPerformed

    }//GEN-LAST:event_btncobroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Venta().setVisible(true);
            }
        });
    }

    private void pintarimagen(JLabel lbl, String ruta) {
        this.imagen = new ImageIcon(ruta);
        this.icono = new ImageIcon(
                this.imagen.getImage().getScaledInstance(
                        lbl.getWidth(),
                        lbl.getHeight(),
                        Image.SCALE_DEFAULT));
        lbl.setIcon(this.icono);
    }

    private double calcularTotal() {
        double sumaTotal = 0.0;
        DefaultTableModel model = (DefaultTableModel) contenido.getModel();

        for (int i = 0; i < model.getRowCount(); i++) {
            sumaTotal += Double.parseDouble(model.getValueAt(i, 4).toString());
        }

        return sumaTotal;
    }

    private void actualizarTotal() {
        double total = calcularTotal();
        sumatotal.setText(String.format("$ %.2f", total));
    }

    private void eliminarFilasSeleccionadas() {
        int[] filasSeleccionadas = contenido.getSelectedRows();

        if (filasSeleccionadas.length > 0) {
            int opcion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Eliminar " + filasSeleccionadas.length + " productos?",
                    "Confirmación",
                    JOptionPane.YES_NO_OPTION
            );

            if (opcion == JOptionPane.YES_OPTION) {
                DefaultTableModel model = (DefaultTableModel) contenido.getModel();

                // Eliminar en orden inverso para evitar desfases
                for (int i = filasSeleccionadas.length - 1; i >= 0; i--) {
                    model.removeRow(filasSeleccionadas[i]);
                }

                actualizarTotal();
            }
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione al menos una fila",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncobro;
    private javax.swing.JTextField buscar;
    private javax.swing.JLabel busqueda;
    private javax.swing.JTable contenido;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel logo1;
    private javax.swing.JLabel sumatotal;
    private javax.swing.JLabel txtfecha;
    // End of variables declaration//GEN-END:variables

}
