/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmacia_san_antonio;

/**
 *
 * @author frix4
 */
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Ticket {
    private LocalDateTime fechaHora;
    private String cliente;
    private List<Object[]> productos;
    private double total;
    
    public Ticket(String cliente, List<Object[]> productos, double total) {
        this.fechaHora = LocalDateTime.now();
        this.cliente = cliente;
        this.productos = new ArrayList<>(productos);
        this.total = total;
    }
    
    // Getters y método para convertir a CSV
    public String toCSV() {
        StringBuilder sb = new StringBuilder();
        sb.append(fechaHora).append(";")
          .append(cliente).append(";")
          .append(total).append(";");
        
        for(Object[] producto : productos) {
            sb.append(producto[0]).append(",")  // Nombre
              .append(producto[2]).append(",")  // Precio
              .append(producto[3]).append(";"); // Cantidad
        }
        
        return sb.toString();
    }
}
