
package conexión;


import java.time.LocalDateTime;

public class Usuario {
    // Atributos (mapeo 1:1 con la tabla usuarios)
    private int idUsuario;
    private String nombreCompleto;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String correo;
    private String user;
    private String rol; // ENUM: vendedor, auxiliar, cajero
    private String turno; // ENUM: turno 1, turno 2
    private String contrasenaHash;
    private LocalDateTime fechaRegistro;
    private boolean activo;
    private int id_tipo;

    public int getId_tipo() {
        return id_tipo;
    }

    public void setId_tipo(int id_tipo) {
        this.id_tipo = id_tipo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getContrasenaHash() {
        return contrasenaHash;
    }

    public void setContrasenaHash(String contrasenaHash) {
        this.contrasenaHash = contrasenaHash;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
public Usuario(){}

    public Usuario(int idUsuario, String nombreCompleto, String apellidoPaterno, String apellidoMaterno, String correo, String user, String rol, String turno, String contrasenaHash, LocalDateTime fechaRegistro, boolean activo, int id_tipo) {
        this.idUsuario = idUsuario;
        this.nombreCompleto = nombreCompleto;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.correo = correo;
        this.user = user;
        this.rol = rol;
        this.turno = turno;
        this.contrasenaHash = contrasenaHash;
        this.fechaRegistro = fechaRegistro;
        this.activo = activo;
        this.id_tipo = id_tipo;
    }

   
}
